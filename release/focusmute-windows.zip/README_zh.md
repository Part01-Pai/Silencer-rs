# FocusMute（Rust 重构）

本项目是对原 C# 版 FocusMute 的 Rust 重构实现。该应用会根据当前前台窗口自动静音或恢复后台应用的声音，旨在在切换窗口时避免不必要的声音干扰。

## 功能

- **黑名单模式**：列入黑名单的进程在不处于前台时会被静音。
- **白名单模式**：仅允许白名单中的进程在后台不被静音，其它进程在后台时会被静音。
- **自动静音**：实时监听前台窗口变化并更新音频会话状态。
- **防抖与同步**：针对快速切换窗口的场景进行了防抖（例如 50ms）与周期性强制同步（例如 200ms），减少漏静音或误静音的情况。
- **多实例支持**：可按进程名或特定 PID 对不同实例进行区分管理。
- **现代化界面**：基于 `egui` 的卡片式 UI，支持中文显示与友好交互。

## 先决条件

- 已安装 Rust（stable 版本）
- Windows 操作系统（使用 WASAPI 与 Win32 API）
- 若使用 MSVC 工具链，请安装 Visual Studio Build Tools

## 编译

在仓库根目录运行：

```powershell
cargo build --release
```

## 运行

```powershell
cargo run --release
```

## 实现细节

- **UI**：使用 [egui](https://github.com/emilk/egui) 与 `eframe` 构建轻量界面。
- **Windows API**：通过官方 `windows`（windows-rs）封装调用 Win32/COM 接口。
- **音频**：与 WASAPI（如 `IAudioSessionManager2`、`ISimpleAudioVolume` 等）进行交互以实现对会话的静音控制。
- **事件监听**：使用 `SetWinEventHook` 监听 `EVENT_SYSTEM_FOREGROUND` 事件以感知前台窗口变化。

## 赞助

如果你愿意支持本项目发展，欢迎赞助，感谢你的支持！

![赞助](photo/zanzhu.png)

再次感谢你的关注与支持！
