# FocusMute Rust

A Rust refactor of the C# FocusMute project. This application mutes background applications based on the foreground window.

## Features

- **Blacklist Mode**: Mutes all processes in the list except when they are in the foreground.
- **Whitelist Mode**: Mutes all processes NOT in the list except when they are in the foreground.
- **自动静音**: 实时检测前台窗口变化并更新音频状态。
- **防抖与同步**: 针对快速切屏进行了优化，包含 50ms 防抖和 200ms 周期性强制同步，防止漏音。
- **多实例区分**: 支持按进程名或特定 PID 实例进行管理。
- **现代 UI**: 基于 egui 的圆角卡片式设计，支持中文显示。

## Prerequisites

- Rust (stable)
- Windows OS (uses WASAPI and Win32 APIs)
- Visual Studio Build Tools (for MSVC linker)

## How to Build

```powershell
cargo build --release
```

## How to Run

```powershell
cargo run --release
```

## Implementation Details

- **UI**: Built with [egui](https://github.com/emilk/egui) and [eframe](https://github.com/emilk/egui/tree/master/crates/eframe).
- **Windows API**: Uses the official [windows-rs](https://github.com/microsoft/windows-rs) crate.
- **Audio**: Interacts with WASAPI (`IAudioSessionManager2`, `ISimpleAudioVolume`, etc.).
- **Events**: Uses `SetWinEventHook` to listen for `EVENT_SYSTEM_FOREGROUND`.
